        <footer class="site-footer">
            <div class="footer-content">
                <div class="footer-col">
                </div>
                <div class="footer-col footer-col--large">
                </div>
                <div class="copyrights">
                    <a href="#">Условия использования сервиса</a> © 2014—2016
                </div>
            </div>
        </footer>
        <div class="drop-overlay"></div>
    </div>
    <!-- END SITE-WRAPPER -->

    <? foreach( $js as $val ){ ?>
        <script src="<?=$val;?>"></script>
    <? } ?>
    <!-- <script src="js/main2.js"></script> -->

</body>
</html>