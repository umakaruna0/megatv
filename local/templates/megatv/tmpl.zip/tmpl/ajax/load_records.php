<?
	// ПЕРЕДАЮ ПАРАМЕТРЫ

	// broadcastID - Последний ID бродкаста на текущий момент, результаты нужно вывести идущие после этого ID;
	// categoryID - ID категории (Пример: d-s);
	// countItems - Количество результатов;
?>
[
	{
		"id": "321",
		"time": "15:40",
		"date": "19.07.2016",
		"link": "/channels/rossiya-k/ispanskiy-sled/",
		"name": "Ментовские войны-5",
		"image": "http://tvguru.com.images.1c-bitrix-cdn.ru/upload/epg_cut/387512_288_288.jpg",
		"category": {
			"link": "d-s",
			"name": "Д/с"
		}
	},
	{
		"id": "321",
		"time": "15:40",
		"date": "19.07.2016",
		"link": "/channels/rossiya-k/ispanskiy-sled/",
		"name": "Ментовские войны-5",
		"image": "http://tvguru.com.images.1c-bitrix-cdn.ru/upload/epg_cut/387512_288_288.jpg",
		"category": {
			"link": "d-s",
			"name": "Д/с"
		}
	},
	{
		"id": "321",
		"time": "15:40",
		"date": "19.07.2016",
		"link": "/channels/rossiya-k/ispanskiy-sled/",
		"name": "Ментовские войны-5",
		"image": "http://tvguru.com.images.1c-bitrix-cdn.ru/upload/epg_cut/387512_288_288.jpg",
		"category": {
			"link": "d-s",
			"name": "Д/с"
		}
	}
]