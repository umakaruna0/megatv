/* global Box */
Box.Application.addService('cookies', function (context) {
	'use strict';

	// --------------------------------------------------------------------------
	// Private
	// --------------------------------------------------------------------------
	var Cookies = context.getGlobal('Cookies');

	// --------------------------------------------------------------------------
	// Public
	// --------------------------------------------------------------------------

	return {

		set: function (name, value, options) {
			return Cookies.set(name, value, options);
		},
		get: function (name) {
			return Cookies.get(name);
		},
		getJSON: function (name) {
			return Cookies.getJSON(name);
		},
		remove: function (name) {
			return Cookies.remove(name);
		}

	};
});
